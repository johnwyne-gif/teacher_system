Quick install steps:

Start XAMPP (Apache + MySQL).

Copy the extracted folder into C:\xampp\htdocs\ (rename folder as you like).

Open phpMyAdmin → Import create_database.sql.

Visit http://localhost/<folder>/ — login with admin@gmail.com
 / 12345.

You're ready to test.