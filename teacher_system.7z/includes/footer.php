</main>
<footer class="footer">Built with ❤️ — Teacher Profiling System</footer>
</body>
</html>
